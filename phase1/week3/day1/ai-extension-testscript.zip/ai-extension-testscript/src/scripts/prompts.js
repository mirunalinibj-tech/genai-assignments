/**
 * Collection of default prompts for different use cases (ICE POT Format)
 */
export const DEFAULT_PROMPTS = {
 
  /**
   * Selenium Java Page Object Prompt (No Test Class)
   */
  SELENIUM_JAVA_PAGE_ONLY: `
    Instructions:
    - Generate ONLY a Selenium Java Page Object Class (no test code).
    - Add JavaDoc for methods & class.
    - Use Selenium 2.30+ compatible imports.
    - Use meaningful method names.
    - Do NOT include explanations or test code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`java
    package com.testleaf.pages;

    /**
     * Page Object for Component Page
     */
    public class ComponentPage {
        // Add methods as per the DOM
    }
    \`\`\`

    Persona:
    - Audience: Automation engineer focusing on maintainable POM structure.

    Output Format:
    - A single Java class inside a \`\`\`java\`\`\` block.

    Tone:
    - Clean, maintainable, enterprise-ready.
  `,

  /**
   * Cucumber Feature File Only Prompt
   */
  CUCUMBER_ONLY: `
    Instructions:
    - Generate ONLY a Cucumber (.feature) file.
    - Use Scenario Outline with Examples table.
    - Make sure every step is relevant to the provided DOM.
    - Do not combine multiple actions into one step.
    - Use South India realistic dataset (names, addresses, pin codes, mobile numbers).
    - Use dropdown values only from provided DOM.
    - Generate multiple scenarios if applicable.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
      | "testuser" | "testpass"|
      | "admin"    | "admin123"|
    \`\`\`

    Persona:
    - Audience: BDD testers who only need feature files.

    Output Format:
    - Only valid Gherkin in a \`\`\`gherkin\`\`\` block.

    Tone:
    - Clear, structured, executable.
  `,

  /**
   * Testcase Generation Prompt
   */
  TESTCASE_GENERATION: `
    Instructions:
    - Generate a structured set of test cases for the selected UI.
    - Use the DOM context to identify inputs, buttons, links, dropdowns, and workflows.
    - For each test case include:
      * Test Case Title
      * Preconditions
      * Step-by-step actions
      * Test data where applicable
      * Expected result
    - Do NOT generate implementation code, page objects, or step definitions.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    | S.No | Title | Test Step | Expected Results |
    |------|-------|-----------|-----------------|
    | 1 | Display My Inpatients dashboard for authorized consultant | Log in with valid consultant credentials | The user has logged in successfully |
    | 2 | Display My Inpatients dashboard for authorized consultant | Navigate to the Consultant Dashboard | The user has navigated to consultant dashboard |
    | 3 | Display My Inpatients dashboard for authorized consultant | Select the 'My Inpatients' section | Dashboard loads within 2 seconds and shows a list of inpatients with correct visualizations (charts, tables) for the logged-in consultant |

    Persona:
    - Audience: QA engineer writing manual or automation test cases.

    Output Format:
    - A single Markdown table with these columns: S.No, Title, Test Step, Expected Results.
    - Do not include any extra headings, paragraphs, or explanation outside the table.

    Tone:
    - Clear, concise, actionable.
  `,

  /**
   * Cucumber with Step Definitions
   */
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: `
    Instructions:
    - Generate BOTH:
      1. A Cucumber .feature file.
      2. A Java step definition class for selenium.
    - Do NOT include Page Object code.
    - Step defs must include WebDriver setup, explicit waits, and actual Selenium code.
    - Use Scenario Outline with Examples table (South India realistic data).

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
\      | "admin"    | "admin123"|
    \`\`\`

    \`\`\`java
    package com.leaftaps.stepdefs;

    import io.cucumber.java.en.*;
    import org.openqa.selenium.*;
    import org.openqa.selenium.chrome.ChromeDriver;
    import org.openqa.selenium.support.ui.*;

    public class LoginStepDefinitions {
        private WebDriver driver;
        private WebDriverWait wait;

        @io.cucumber.java.Before
        public void setUp() {
            driver = new ChromeDriver();
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.manage().window().maximize();
        }

        @io.cucumber.java.After
        public void tearDown() {
            if (driver != null) driver.quit();
        }

        @Given("I open the login page")
        public void openLoginPage() {
            driver.get("\${pageUrl}");
        }

        @When("I type {string} into the Username field")
        public void enterUsername(String username) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("username")));
            el.sendKeys(username);
        }

        @When("I type {string} into the Password field")
        public void enterPassword(String password) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("password")));
            el.sendKeys(password);
        }

        @When("I click the Login button")
        public void clickLogin() {
            driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
        }

        @Then("I should be logged in successfully")
        public void verifyLogin() {
            WebElement success = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("success")));
            assert success.isDisplayed();
        }
    }
    \`\`\`

    Persona:
    - Audience: QA engineers working with Cucumber & Selenium.

    Output Format:
    - Gherkin in \`\`\`gherkin\`\`\` block + Java code in \`\`\`java\`\`\` block.

    Tone:
    - Professional, executable, structured.
  `,

  /**
   * Playwright TypeScript Page Object Model (No Test)
   */
  PLAYWRIGHT_TYPESCRIPT_POM: `
    Instructions:
    - Generate ONLY a Playwright TypeScript Page Object Model class (no test code).
    - Add JSDoc comments for all methods and the class.
    - Use Playwright locators (page.locator(), page.getByRole(), page.getByLabel(), etc.).
    - Make all methods async and use async/await syntax.
    - Use meaningful method names following camelCase convention.
    - Do NOT include test code or fixture setup.
    - Do NOT include test file runner logic.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`typescript
    import { Page, Locator } from '@playwright/test';

    /**
     * Page Object Model for Login Page
     */
    export class LoginPage {
        readonly page: Page;
        readonly usernameInput: Locator;
        readonly passwordInput: Locator;
        readonly loginButton: Locator;

        constructor(page: Page) {
            this.page = page;
            this.usernameInput = page.locator('input[id="username"]');
            this.passwordInput = page.locator('input[id="password"]');
            this.loginButton = page.locator('button:has-text("Login")');
        }

        /**
         * Navigate to the login page
         */
        async goto(): Promise<void> {
            await this.page.goto('/login');
        }

        /**
         * Enter username in the username field
         */
        async enterUsername(username: string): Promise<void> {
            await this.usernameInput.fill(username);
        }

        /**
         * Enter password in the password field
         */
        async enterPassword(password: string): Promise<void> {
            await this.passwordInput.fill(password);
        }

        /**
         * Click the login button
         */
        async clickLogin(): Promise<void> {
            await this.loginButton.click();
        }
    }
    \`\`\`

    Persona:
    - Audience: Automation engineers building maintainable Playwright test suites.

    Output Format:
    - A single TypeScript class inside a \`\`\`typescript\`\`\` block.

    Tone:
    - Modern, async-first, enterprise-ready for Playwright.
  `,

  /**
   * Playwright TypeScript Test Spec Only
   */
  PLAYWRIGHT_TYPESCRIPT_SPEC: `
    Instructions:
    - Generate ONLY a Playwright TypeScript test specification file (no Page Object).
    - Use @playwright/test framework with test() and expect().
    - Include test.beforeEach() and test.afterEach() hooks.
    - Create test scenarios based on the provided DOM.
    - Use async/await syntax throughout.
    - Do NOT import or reference external Page Objects.
    - Do NOT include Page Object code.
    - Use descriptive test names and assertions.
    - Use South India realistic dataset (names, addresses, pin codes).
    - Use dropdown values only from provided DOM.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`typescript
    import { test, expect, Page } from '@playwright/test';

    test.describe('Login to Application', () => {
        let page: Page;

        test.beforeEach(async ({ page: testPage }) => {
            page = testPage;
            await page.goto('\${pageUrl}');
        });

        test('Successful login with valid credentials', async () => {
            await page.locator('input[id="username"]').fill('admin');
            await page.locator('input[id="password"]').fill('admin123');
            await page.locator('button:has-text("Login")').click();
            
            await expect(page).toHaveURL('**/dashboard');
        });

        test('Failed login with invalid credentials', async () => {
            await page.locator('input[id="username"]').fill('invalid');
            await page.locator('input[id="password"]').fill('wrongpassword');
            await page.locator('button:has-text("Login")').click();
            
            await expect(page.locator('text=Invalid credentials')).toBeVisible();
        });
    });
    \`\`\`

    Persona:
    - Audience: QA engineers writing Playwright tests with direct DOM interaction.

    Output Format:
    - TypeScript test code in a \`\`\`typescript\`\`\` block.

    Tone:
    - Clear, async-first, executable immediately.
  `,

  /**
   * Playwright TypeScript Page Object Model + Test Spec Combined
   */
  PLAYWRIGHT_TYPESCRIPT_POM_AND_SPEC: `
    Instructions:
    - Generate BOTH:
      1. A Playwright TypeScript Page Object Model class.
      2. A Playwright TypeScript test specification file that uses the POM.
    - Do NOT include explanations between code blocks.
    - Page Object: Use async methods, Playwright locators, JSDoc comments.
    - Test Spec: Import and use the Page Object from the POM, create realistic test scenarios.
    - Both files must be complete, standalone, and immediately executable.
    - Use South India realistic dataset for test data.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example format:

    \`\`\`typescript
    // pages/LoginPage.ts
    import { Page, Locator } from '@playwright/test';

    export class LoginPage {
        readonly page: Page;
        readonly usernameInput: Locator;
        readonly passwordInput: Locator;
        readonly loginButton: Locator;

        constructor(page: Page) {
            this.page = page;
            this.usernameInput = page.locator('input[id="username"]');
            this.passwordInput = page.locator('input[id="password"]');
            this.loginButton = page.locator('button:has-text("Login")');
        }

        async goto(): Promise<void> {
            await this.page.goto('\${pageUrl}');
        }

        async enterUsername(username: string): Promise<void> {
            await this.usernameInput.fill(username);
        }

        async enterPassword(password: string): Promise<void> {
            await this.passwordInput.fill(password);
        }

        async clickLogin(): Promise<void> {
            await this.loginButton.click();
        }
    }
    \`\`\`

    \`\`\`typescript
    // tests/login.spec.ts
    import { test, expect, Page } from '@playwright/test';
    import { LoginPage } from '../pages/LoginPage';

    test.describe('Login to Application', () => {
        let page: Page;
        let loginPage: LoginPage;

        test.beforeEach(async ({ page: testPage }) => {
            page = testPage;
            loginPage = new LoginPage(page);
            await loginPage.goto();
        });

        test('Successful login with valid credentials', async () => {
            await loginPage.enterUsername('admin');
            await loginPage.enterPassword('admin123');
            await loginPage.clickLogin();
            
            await expect(page).toHaveURL('**/dashboard');
        });
    });
    \`\`\`

    Persona:
    - Audience: QA engineers implementing complete Playwright test suites with POM architecture.

    Output Format:
    - First \`\`\`typescript\`\`\` block: Page Object Model code
    - Second \`\`\`typescript\`\`\` block: Test specification code

    Tone:
    - Professional, modular, production-ready architecture.
  `,

  /**
   * Java Selenium Test Script
   */
  TEST_SCRIPT_JAVA_SELENIUM: `
    Instructions:
    - Generate a single Java Selenium test script using JUnit or TestNG.
    - Use WebDriver setup, explicit waits, and clean element locators.
    - The script should be directly executable within a Java test project.
    - Include one or more realistic test methods based on the provided DOM.
    - Do NOT generate Page Object code unless explicitly requested.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`java
    import org.junit.jupiter.api.*;
    import org.openqa.selenium.*;
    import org.openqa.selenium.chrome.ChromeDriver;
    import org.openqa.selenium.support.ui.ExpectedConditions;
    import org.openqa.selenium.support.ui.WebDriverWait;

    public class LoginTest {
        private WebDriver driver;
        private WebDriverWait wait;

        @BeforeEach
        public void setUp() {
            driver = new ChromeDriver();
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.manage().window().maximize();
            driver.get("\${pageUrl}");
        }

        @Test
        public void testSuccessfulLogin() {
            driver.findElement(By.id("username")).sendKeys("admin");
            driver.findElement(By.id("password")).sendKeys("password123");
            driver.findElement(By.cssSelector("button[type='submit']")).click();
            wait.until(ExpectedConditions.urlContains("dashboard"));
            Assertions.assertTrue(driver.getCurrentUrl().contains("dashboard"));
        }

        @AfterEach
        public void tearDown() {
            if (driver != null) {
                driver.quit();
            }
        }
    }
    \`\`\`

    Persona:
    - Audience: automation engineers writing executable Java Selenium tests.

    Output Format:
    - One Java test script inside a \`\`\`java\`\`\` block.
    - No explanatory text outside the code block.

    Tone:
    - Clean, executable, professional.
  `,

  /**
   * C# Selenium Test Script
   */
  TEST_SCRIPT_CSHARP_SELENIUM: `
    Instructions:
    - Generate a single C# Selenium test script using NUnit or MSTest.
    - Use WebDriver setup, explicit waits, and clean selectors.
    - The script should be directly executable within a C# test project.
    - Include realistic test methods based on the provided DOM.
    - Do NOT generate Page Object code unless explicitly requested.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`csharp
    using NUnit.Framework;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Support.UI;
    using System;

    namespace Tests {
        public class LoginTests {
            private IWebDriver driver;
            private WebDriverWait wait;

            [SetUp]
            public void SetUp() {
                driver = new ChromeDriver();
                wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                driver.Manage().Window.Maximize();
                driver.Navigate().GoToUrl("\${pageUrl}");
            }

            [Test]
            public void TestSuccessfulLogin() {
                driver.FindElement(By.Id("username")).SendKeys("admin");
                driver.FindElement(By.Id("password")).SendKeys("password123");
                driver.FindElement(By.CssSelector("button[type='submit']")).Click();
                wait.Until(ExpectedConditions.UrlContains("dashboard"));
                Assert.IsTrue(driver.Url.Contains("dashboard"));
            }

            [TearDown]
            public void TearDown() {
                driver.Quit();
            }
        }
    }
    \`\`\`

    Persona:
    - Audience: automation engineers writing executable C# Selenium tests.

    Output Format:
    - One C# test script inside a \`\`\`csharp\`\`\` block.
    - No explanatory text outside the code block.

    Tone:
    - Clear, concise, executable.
  `,

  /**
   * Python Selenium Test Script
   */
  TEST_SCRIPT_PYTHON_SELENIUM: `
    Instructions:
    - Generate a single Python Selenium test script using pytest.
    - Use WebDriver setup, explicit waits, and readable locators.
    - The script should be directly executable within a pytest environment.
    - Include realistic test functions based on the provided DOM.
    - Do NOT generate Page Object code unless explicitly requested.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`python
    import pytest
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    @pytest.fixture
    def driver():
        driver = webdriver.Chrome()
        driver.maximize_window()
        yield driver
        driver.quit()

    def test_successful_login(driver):
        driver.get("\${pageUrl}")
        driver.find_element(By.ID, "username").send_keys("admin")
        driver.find_element(By.ID, "password").send_keys("password123")
        driver.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
        WebDriverWait(driver, 10).until(EC.url_contains("dashboard"))
        assert "dashboard" in driver.current_url
    \`\`\`

    Persona:
    - Audience: automation engineers writing executable Python Selenium tests.

    Output Format:
    - One Python test script inside a \`\`\`python\`\`\` block.
    - No explanatory text outside the code block.

    Tone:
    - Practical, executable, minimal.
  `,

  /**
   * Playwright TypeScript Test Script
   */
  TEST_SCRIPT_PLAYWRIGHT_TYPESCRIPT: `
    Instructions:
    - Generate a single Playwright TypeScript test file using @playwright/test.
    - Use test.describe, test.beforeEach, and test() with expect().
    - The script should be directly executable in a Playwright project.
    - Include realistic test scenarios based on the provided DOM.
    - Do NOT generate separate Page Object code unless explicitly requested.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`typescript
    import { test, expect } from '@playwright/test';

    test.describe('Login flow', () => {
      test.beforeEach(async ({ page }) => {
        await page.goto('\${pageUrl}');
      });

      test('should log in successfully with valid credentials', async ({ page }) => {
        await page.fill('input[id="username"]', 'admin');
        await page.fill('input[id="password"]', 'password123');
        await page.click('button[type="submit"]');
        await expect(page).toHaveURL(/dashboard/);
      });
    });
    \`\`\`

    Persona:
    - Audience: automation engineers writing executable Playwright tests.

    Output Format:
    - One TypeScript test script inside a \`\`\`typescript\`\`\` block.
    - No explanatory text outside the code block.

    Tone:
    - Modern, async-first, executable.
  `,

  /**
   * Cypress TypeScript Test Script
   */
  TEST_SCRIPT_CYPRESS_TYPESCRIPT: `
    Instructions:
    - Generate a single Cypress TypeScript test file.
    - Use describe, it, cy.visit, cy.get, and assertions.
    - The script should be directly executable in a Cypress project.
    - Include realistic test cases based on the provided DOM.
    - Do NOT generate Page Object code unless explicitly requested.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`typescript
    describe('Login flow', () => {
      it('logs in successfully with valid credentials', () => {
        cy.visit('\${pageUrl}');
        cy.get('input[id="username"]').type('admin');
        cy.get('input[id="password"]').type('password123');
        cy.get('button[type="submit"]').click();
        cy.url().should('include', 'dashboard');
      });
    });
    \`\`\`

    Persona:
    - Audience: automation engineers writing executable Cypress tests.

    Output Format:
    - One TypeScript test script inside a \`\`\`typescript\`\`\` block.
    - No explanatory text outside the code block.

    Tone:
    - Practical, executable, minimal.
  `,

  /**
   * Puppeteer TypeScript Test Script
   */
  TEST_SCRIPT_PUPPETEER_TYPESCRIPT: `
    Instructions:
    - Generate a single Puppeteer TypeScript test script.
    - Use Puppeteer APIs for browser launch, navigation, selectors, and assertions.
    - The script should be directly executable in a Puppeteer project.
    - Include realistic test flows based on the provided DOM.
    - Do NOT generate Page Object code unless explicitly requested.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`typescript
    import puppeteer from 'puppeteer';

    (async () => {
      const browser = await puppeteer.launch({ headless: true });
      const page = await browser.newPage();
      await page.goto('\${pageUrl}');
      await page.type('input[id="username"]', 'admin');
      await page.type('input[id="password"]', 'password123');
      await page.click('button[type="submit"]');
      await page.waitForNavigation();
      console.log(await page.url());
      await browser.close();
    })();
    \`\`\`

    Persona:
    - Audience: automation engineers writing executable Puppeteer scripts.

    Output Format:
    - One TypeScript script inside a \`\`\`typescript\`\`\` block.
    - No explanatory text outside the code block.

    Tone:
    - Practical, executable, minimal.
  `
};

/**
 * Helper function to escape code blocks in prompts
 */
function escapeCodeBlocks(text) {
  return text.replace(/```/g, '\\`\\`\\`');
}

/**
 * Function to fill template variables in a prompt
 */
export function getPrompt(promptKey, variables = {}) {
  let prompt = DEFAULT_PROMPTS[promptKey];
  if (!prompt) {
    throw new Error(`Prompt not found: ${promptKey}`);
  }

  Object.entries(variables).forEach(([k, v]) => {
    const regex = new RegExp(`\\$\\{${k}\\}`, 'g');
    prompt = prompt.replace(regex, v);
  });

  return prompt.trim();
}

export const CODE_GENERATOR_TYPES = {
  SELENIUM_JAVA_PAGE_ONLY: 'Selenium-Java-Page-Only',
  CUCUMBER_ONLY: 'Cucumber-Only',
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: 'Cucumber-With-Selenium-Java-Steps',
  PLAYWRIGHT_TYPESCRIPT_POM: 'Playwright-TypeScript-POM',
  PLAYWRIGHT_TYPESCRIPT_SPEC: 'Playwright-TypeScript-Spec',
  PLAYWRIGHT_TYPESCRIPT_POM_AND_SPEC: 'Playwright-TypeScript-POM-And-Spec',
};
